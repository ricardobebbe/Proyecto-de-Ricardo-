@echo off

set EMU_PATH=EMU

echo Starting EMU...

cd %EMU_PATH%

start DataServer.exe
start ExDB.exe
start EventServer.exe
start RankingServer.exe
start JoinServer.exe
start ConnectServer.exe

echo EMU started.

pause
