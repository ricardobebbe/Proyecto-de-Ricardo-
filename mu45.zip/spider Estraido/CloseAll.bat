@echo off

echo WARNING: for testing only!

TSKILL GameServer
TSKILL DataServer
TSKILL ExDB
TSKILL EventServer
TSKILL RankingServer
TSKILL JoinServer
TSKILL ConnectServer

pause
