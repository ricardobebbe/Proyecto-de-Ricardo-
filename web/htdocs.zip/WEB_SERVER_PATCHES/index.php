<?php
echo "Acceso restringido";
?>