<?php
/**
 * Instalador web de AT_Web
 * Se ejecuta una sola vez. Cuando termina crea Configuraciones/instalado.lock
 * y hay que borrar esta carpeta del servidor.
 */
session_start();
mb_internal_encoding('UTF-8');
header('Content-Type: text/html; charset=UTF-8');

define('RAIZ', dirname(__DIR__));
require_once RAIZ . '/Seguridad/mssql_compat.php';

$LOCK = RAIZ . '/Configuraciones/instalado.lock';
$paso = isset($_GET['paso']) ? (int) $_GET['paso'] : 1;
if ($paso < 1 || $paso > 5) { $paso = 1; }
if (file_exists($LOCK) && !isset($_GET['forzar'])) { $paso = 5; }

function esc($v) { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }
function dato($k, $def = '') { return isset($_SESSION['inst'][$k]) ? $_SESSION['inst'][$k] : $def; }
if (!isset($_SESSION['inst'])) { $_SESSION['inst'] = array(); }

$errores = array();
$exitos  = array();

/* ------------------------------------------------------- Requisitos */
$req = array();
$req[] = array('PHP 7.0 o superior', version_compare(PHP_VERSION, '7.0', '>='), PHP_VERSION, true);
$drv = AT_DB::driversDisponibles();
$req[] = array('Driver de SQL Server (sqlsrv / pdo_sqlsrv / dblib / odbc)', count($drv) > 0,
               count($drv) ? implode(', ', $drv) : 'ninguno instalado', true);
$req[] = array('Extensión mbstring', extension_loaded('mbstring'), extension_loaded('mbstring') ? 'ok' : 'falta', false);
$req[] = array('Escritura en /Configuraciones', is_writable(RAIZ . '/Configuraciones'), is_writable(RAIZ . '/Configuraciones') ? 'ok' : 'chmod 755', true);
$req[] = array('Escritura en /Logs', is_writable(RAIZ . '/Logs'), is_writable(RAIZ . '/Logs') ? 'ok' : 'chmod 755', false);
$puedeSeguir = true;
foreach ($req as $r) { if ($r[3] && !$r[1]) { $puedeSeguir = false; } }

/* ------------------------------------------------------- Acciones */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['probar'])) {
        foreach (array('host','usuario','clave','base','driver','md5') as $k) {
            $_SESSION['inst'][$k] = isset($_POST[$k]) ? trim($_POST[$k]) : '';
        }
        $db = new AT_DB();
        if ($db->connect(dato('host'), dato('usuario'), dato('clave'), dato('base'), dato('driver', 'auto'))) {
            $r = $db->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='MEMB_INFO'");
            $f = $r ? $r->fetch() : null;
            if ($f && (int) $f[0] > 0) {
                $exitos[] = 'Conexión correcta con el driver <b>' . esc($db->driver) . '</b> y la tabla MEMB_INFO existe.';
                $_SESSION['inst']['ok'] = 1;
                $paso = 3;
            } else {
                $errores[] = 'Se conectó a la base, pero no se encontró la tabla <b>MEMB_INFO</b>. ¿Es la base MuOnline correcta?';
                $paso = 2;
            }
        } else {
            $errores[] = 'No se pudo conectar: ' . esc($db->lastError);
            $paso = 2;
        }
    }

    if (isset($_POST['estructura'])) {
        $db = new AT_DB();
        if (!$db->connect(dato('host'), dato('usuario'), dato('clave'), dato('base'), dato('driver', 'auto'))) {
            $errores[] = 'Se perdió la conexión: ' . esc($db->lastError);
            $paso = 2;
        } else {
            $sql = file_get_contents(RAIZ . '/sql/01_estructura_web.sql');
            $lotes = preg_split('/^\s*GO\s*$/mi', $sql);
            $fallos = 0;
            foreach ($lotes as $lote) {
                $lote = trim(preg_replace('/^\s*USE\s+\w+;?\s*$/mi', '', $lote));
                if ($lote === '') { continue; }
                if ($db->query($lote) === false) { $fallos++; $errores[] = 'SQL: ' . esc($db->lastError); }
            }
            if ($fallos === 0) { $exitos[] = 'Estructura de la web aplicada en la base de datos.'; }
            $paso = 4;
        }
    }

    if (isset($_POST['finalizar'])) {
        $admin = preg_replace('/[^A-Za-z0-9_\-]/', '', isset($_POST['admin']) ? $_POST['admin'] : '');
        $db = new AT_DB();
        if (!$db->connect(dato('host'), dato('usuario'), dato('clave'), dato('base'), dato('driver', 'auto'))) {
            $errores[] = 'Se perdió la conexión: ' . esc($db->lastError);
            $paso = 2;
        } else {
            if ($admin !== '') {
                $a = str_replace("'", "''", $admin);
                $r = $db->query("SELECT COUNT(*) FROM MEMB_INFO WHERE memb___id='$a'");
                $f = $r ? $r->fetch() : null;
                if (!$f || (int) $f[0] === 0) {
                    $errores[] = 'La cuenta <b>' . esc($admin) . '</b> no existe. Creala primero desde el registro de la web.';
                } elseif ($db->query("UPDATE MEMB_INFO SET CuentaGM=3 WHERE memb___id='$a'") === false) {
                    $errores[] = 'No se pudo dar permisos de administrador: ' . esc($db->lastError);
                } else {
                    $exitos[] = 'La cuenta <b>' . esc($admin) . '</b> ahora es administradora del panel.';
                }
            }

            if (!$errores) {
                $cfg = "<?php\n"
                     . "//---------------------------------------------------------------\n"
                     . "// Generado por el instalador - " . date('Y-m-d H:i:s') . "\n"
                     . "//---------------------------------------------------------------\n"
                     . '$UsuarioSQL     = ' . var_export(dato('usuario'), true) . ";\n"
                     . '$ContraseñaSQL  = ' . var_export(dato('clave'), true) . ";\n"
                     . '$IP             = ' . var_export(dato('host'), true) . ";\n"
                     . '$dbsql          = ' . var_export(dato('base'), true) . ";\n"
                     . '$DriverSQL      = ' . var_export(dato('driver', 'auto'), true) . ";\n"
                     . '$md5            = ' . (dato('md5') ? 1 : 0) . ";\n";
                if (file_put_contents(RAIZ . '/Configuraciones/SQL.php', $cfg) === false) {
                    $errores[] = 'No se pudo escribir <b>Configuraciones/SQL.php</b>. Dale permisos de escritura a la carpeta.';
                } else {
                    file_put_contents($LOCK, date('c') . " instalado\n");
                    $_SESSION['inst'] = array();
                    $paso = 5;
                }
            } else {
                $paso = 4;
            }
        }
    }
}
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Instalador — AT_Web</title>
<style>
body{margin:0;background:#0f1216;color:#e6eaf0;font:14px/1.6 "Segoe UI",Arial,sans-serif}
.caja{max-width:820px;margin:36px auto;padding:0 18px}
h1{color:#e0a03a;font-size:22px;margin:0 0 6px}
h2{font-size:17px;margin:22px 0 10px;color:#e0a03a}
.tarjeta{background:#171b21;border:1px solid #2a323c;border-radius:12px;padding:20px;margin-bottom:18px}
.pasos{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0}
.pasos div{flex:1;min-width:120px;text-align:center;padding:9px;border-radius:8px;background:#171b21;border:1px solid #2a323c;font-size:12px;color:#93a1b1}
.pasos div.act{background:#e0a03a;color:#171b21;font-weight:700;border-color:#e0a03a}
label{display:block;color:#93a1b1;font-size:12px;margin:0 0 4px}
input,select{width:100%;background:#0d1014;border:1px solid #2a323c;color:#e6eaf0;padding:9px 11px;border-radius:7px;font:inherit}
.campos{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px;margin-bottom:14px}
.btn{background:#e0a03a;color:#171b21;border:0;padding:10px 18px;border-radius:7px;font-weight:700;cursor:pointer;font-size:14px;text-decoration:none;display:inline-block}
.btn.f{background:transparent;border:1px solid #2a323c;color:#e6eaf0}
table{width:100%;border-collapse:collapse}
td{padding:8px 6px;border-bottom:1px solid #22282f}
.ok{color:#5ee39b}.no{color:#ff8a8a}
.aviso{padding:11px 14px;border-radius:8px;margin-bottom:12px;border:1px solid}
.aviso.b{background:rgba(46,204,113,.12);border-color:#2ecc71;color:#a9f0c8}
.aviso.m{background:rgba(255,82,82,.12);border-color:#ff5252;color:#ffc2c2}
code{background:#0d1014;padding:2px 6px;border-radius:5px;color:#4fc3f7}
.suave{color:#93a1b1}
</style>
</head>
<body>
<div class="caja">
  <h1>Instalador de AT_Web</h1>
  <p class="suave">Configura la conexión a SQL Server, prepara la base y crea el administrador del panel.</p>

  <div class="pasos">
    <?php $nombres = array(1=>'1. Requisitos',2=>'2. Base de datos',3=>'3. Estructura',4=>'4. Administrador',5=>'5. Listo');
    foreach ($nombres as $n => $t): ?>
      <div class="<?php echo $paso === $n ? 'act' : ''; ?>"><?php echo $t; ?></div>
    <?php endforeach; ?>
  </div>

  <?php foreach ($errores as $e): ?><div class="aviso m"><?php echo $e; ?></div><?php endforeach; ?>
  <?php foreach ($exitos as $e): ?><div class="aviso b"><?php echo $e; ?></div><?php endforeach; ?>

<?php if ($paso === 1): ?>
  <div class="tarjeta">
    <h2 style="margin-top:0">Requisitos del servidor</h2>
    <table>
      <?php foreach ($req as $r): ?>
      <tr>
        <td><?php echo esc($r[0]); ?><?php echo $r[3] ? '' : ' <span class="suave">(opcional)</span>'; ?></td>
        <td class="<?php echo $r[1] ? 'ok' : 'no'; ?>" style="text-align:right"><?php echo esc($r[2]); ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
    <?php if (!$puedeSeguir): ?>
      <div class="aviso m" style="margin-top:14px">
        Faltan requisitos obligatorios. En <b>XAMPP</b> instalá los drivers <code>php_sqlsrv</code> y <code>php_pdo_sqlsrv</code>
        (Microsoft Drivers for PHP for SQL Server) y activalos en <code>php.ini</code>.
        En <b>cPanel</b> pedile al hosting que habilite <code>pdo_dblib</code> o <code>sqlsrv</code>.
      </div>
    <?php endif; ?>
    <p style="margin-bottom:0">
      <a class="btn <?php echo $puedeSeguir ? '' : 'f'; ?>" href="index.php?paso=2">Continuar</a>
      <a class="btn f" href="index.php?paso=1">Volver a comprobar</a>
    </p>
  </div>

<?php elseif ($paso === 2): ?>
  <form method="post" class="tarjeta">
    <h2 style="margin-top:0">Datos de SQL Server</h2>
    <div class="campos">
      <div><label>Servidor (IP o IP,puerto)</label><input type="text" name="host" value="<?php echo esc(dato('host', '127.0.0.1')); ?>" required></div>
      <div><label>Base de datos</label><input type="text" name="base" value="<?php echo esc(dato('base', 'MuOnline')); ?>" required></div>
      <div><label>Usuario</label><input type="text" name="usuario" value="<?php echo esc(dato('usuario', 'sa')); ?>" required></div>
      <div><label>Contraseña</label><input type="password" name="clave" value="<?php echo esc(dato('clave')); ?>"></div>
      <div><label>Driver</label>
        <select name="driver">
          <?php foreach (array('auto','sqlsrv','pdo_sqlsrv','pdo_dblib','pdo_odbc','odbc') as $d): ?>
            <option value="<?php echo $d; ?>" <?php echo dato('driver','auto') === $d ? 'selected' : ''; ?>><?php echo $d; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div><label>Contraseñas del GameServer</label>
        <select name="md5">
          <option value="0" <?php echo dato('md5') ? '' : 'selected'; ?>>Texto plano</option>
          <option value="1" <?php echo dato('md5') ? 'selected' : ''; ?>>Encriptadas (MD5 / ChecaSenha)</option>
        </select>
      </div>
    </div>
    <p class="suave">Instalado en la misma PC que SQL Server usá <code>127.0.0.1</code>; si usás una instancia con nombre, probá <code>127.0.0.1,1433</code>.</p>
    <button class="btn" type="submit" name="probar" value="1">Probar conexión y continuar</button>
  </form>

<?php elseif ($paso === 3): ?>
  <form method="post" class="tarjeta">
    <h2 style="margin-top:0">Preparar la base de datos</h2>
    <p>Se van a agregar las columnas y tablas que necesita la web (VIP, créditos, nivel de GM, resets, noticias y logs).
       No se borra ni se modifica ningún dato existente y se puede repetir sin riesgo.</p>
    <button class="btn" type="submit" name="estructura" value="1">Aplicar estructura</button>
    <a class="btn f" href="index.php?paso=4">Omitir (ya la apliqué a mano)</a>
  </form>

<?php elseif ($paso === 4): ?>
  <form method="post" class="tarjeta">
    <h2 style="margin-top:0">Administrador del panel</h2>
    <p>Escribí el nombre de una cuenta ya existente del juego para darle acceso total al panel
       (<code>CuentaGM = 3</code>). Podés dejarlo vacío y hacerlo después desde SQL.</p>
    <div class="campos">
      <div><label>Cuenta administradora</label><input type="text" name="admin" maxlength="20" placeholder="ej: admin"></div>
    </div>
    <button class="btn" type="submit" name="finalizar" value="1">Guardar configuración y terminar</button>
  </form>

<?php else: ?>
  <div class="tarjeta">
    <h2 style="margin-top:0">Instalación finalizada</h2>
    <div class="aviso m"><b>Importante:</b> borrá la carpeta <code>/instalar</code> del servidor ahora mismo.
      Mientras exista, cualquiera podría reconfigurar la web.</div>
    <p>Ya podés entrar al sitio y al panel:</p>
    <p>
      <a class="btn" href="../index.php">Ir al sitio</a>
      <a class="btn f" href="../Panel/Administrador/index.php">Panel de administración</a>
    </p>
    <p class="suave">¿Necesitás cambiar los datos de conexión? Editá <code>Configuraciones/SQL.php</code>
      o borrá <code>Configuraciones/instalado.lock</code> y volvé a correr el instalador.</p>
  </div>
<?php endif; ?>
</div>
</body>
</html>
